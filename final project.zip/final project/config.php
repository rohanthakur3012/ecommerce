<?php

$conn = mysqli_connect('localhost','root','','test_db') or die('connection failed');

?>