<html lang="en" dir="ltr">
   <head>
      <meta charset="utf-8">
      <title>Login</title>
      <link rel="stylesheet" href="login.css">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
   <body>
      <div class="wrapper">
         <div class="title-text">
            <div class="title login">
               Login Form
            </div>
            <div class="title signup">
               Signup Form
            </div>
         </div>
         <div class="form-container">
            <div class="slide-controls">
               <input type="radio" name="slide" id="login" checked>
               <input type="radio" name="slide" id="signup">
               <label for="login" class="slide login">Login</label>
               <label for="signup" class="slide signup">Signup</label>
               <div class="slider-tab"></div>
            </div>
            <div class="form-inner">
               <form action="login.php" class="login" method="post">
			   <?php if (isset($_GET['error'])) { ?>
     		       <p class="error"><?php echo $_GET['error']; ?></p>
     	       <?php } ?>
                  <div class="field">
				   <input type="text" name="uname" placeholder="User Name"><br>
                  </div>
                  <div class="field">
				   <input type="password" name="password" placeholder="Password"><br>
                  </div>
                  <div class="field btn">
                     <div class="btn-layer"></div>
                     <input type="submit" value="Login">
                  </div>
                  <div class="signup-link">
                     Not a member? <a href="">Signup now</a>
                  </div>
               </form>
               <form action="signup-check.php" method="post">
			   <?php if (isset($_GET['error'])) { ?>
     		       <p class="error"><?php echo $_GET['error']; ?></p>
     	       <?php } ?>

               <?php if (isset($_GET['success'])) { ?>
                   <p class="success"><?php echo $_GET['success']; ?></p>
               <?php } ?>
                  <div class="field">
				  <?php if (isset($_GET['name'])) { ?>
                       <input type="text" 
                              name="name" 
                              placeholder="Name"
                              value="<?php echo $_GET['name']; ?>"><br>
                  <?php }else{ ?>
                       <input type="text" 
                              name="name" 
                              placeholder="Name"><br>
                  <?php }?>
				  </div>
                  <div class="field">
				  <?php if (isset($_GET['uname'])) { ?>
                       <input type="text" 
                              name="uname" 
                              placeholder="User Name"
                              value="<?php echo $_GET['uname']; ?>"><br>
                  <?php }else{ ?>
                       <input type="text" 
                              name="uname" 
                              placeholder="User Name"><br>
                  <?php }?>
                  </div>
                  <div class="field">
				  <input type="password" 
                         name="password" 
                         placeholder="Password"><br>
				  </div>
                  <div class="field">
				  <input type="password" 
                         name="re_password" 
                         placeholder="Re_Password"><br>
                  </div>
                  <div class="field btn">
                     <div class="btn-layer"></div>
                     <input type="submit" value="Signup">
                  </div>
                  <a href="index.php" class="ca">Already have an account?</a>
               </form>
            </div>
         </div>
      </div>
      <script>
         const loginText = document.querySelector(".title-text .login");
         const loginForm = document.querySelector("form.login");
         const loginBtn = document.querySelector("label.login");
         const signupBtn = document.querySelector("label.signup");
         const signupLink = document.querySelector("form .signup-link a");
         signupBtn.onclick = (()=>{
           loginForm.style.marginLeft = "-50%";
           loginText.style.marginLeft = "-50%";
         });
         loginBtn.onclick = (()=>{
           loginForm.style.marginLeft = "0%";
           loginText.style.marginLeft = "0%";
         });
         signupLink.onclick = (()=>{
           signupBtn.click();
           return false;
         });
      </script>
   </body>
</html>
</body>
</html>