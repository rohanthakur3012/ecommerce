<header class="header">

   <section class="flex">
      <a href="index.html" class="logo">DreamCart</a>

      <nav class="navbar">
         <a href="add_product.php">add product</a>
      </nav>

      <div id="menu-btn" class="fas fa-bars"></div>
   </section>

</header>