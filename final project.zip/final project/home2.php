<?php 
session_start();

if (isset($_SESSION['id']) && isset($_SESSION['user_name'])) {

 ?>
<!DOCTYPE html>
<html>
<head>
	<title>HOME</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
     <h1>Hello, <?php echo $_SESSION['name']; ?></h1>
     <a href="logout2.php">Logout</a>
     <a href="add_product.php">Continue to seller site</a>
</body>
</html>

<?php 
}else{
     header("Location: index2.php");
     exit();
}
 ?>